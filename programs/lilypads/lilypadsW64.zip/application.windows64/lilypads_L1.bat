@echo off
java -Djava.ext.dirs=lib -Djava.library.path=lib lilypads_L1
